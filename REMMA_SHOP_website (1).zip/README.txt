REMMA SHOP (TM) — Front-End Demo

Files:
- index.html
- style.css
- script.js

How to run:
1. Keep all three files in the same folder.
2. Double-click index.html, or open it with a modern browser.
3. No server or external packages are required.

Included:
- Responsive storefront
- Search
- Category filters
- Sorting
- Product details
- Add/remove/update cart
- LocalStorage cart persistence
- Login/register modal UI
- Checkout form
- Order confirmation
