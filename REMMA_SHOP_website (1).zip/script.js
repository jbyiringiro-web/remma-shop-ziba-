const products=[
{id:1,name:"Samsung Galaxy A54",category:"Electronics",price:299,rating:4.8,icon:"📱",description:"Samsung Galaxy A54 with 128GB storage, 8GB RAM, 5G connectivity and an amazing camera. Perfect for everyday use.",featured:true},
{id:2,name:"Nike Sneakers",category:"Shoes",price:85,rating:4.6,icon:"👟",description:"Comfortable everyday sneakers with a sporty design and cushioned sole.",featured:true},
{id:3,name:"Laptop Backpack",category:"Bags",price:45,rating:4.5,icon:"🎒",description:"Durable backpack with padded laptop compartment and multiple storage pockets.",featured:true},
{id:4,name:"Smart Watch",category:"Accessories",price:60,rating:4.4,icon:"⌚",description:"Smart watch with activity tracking, notifications and a bright display.",featured:true},
{id:5,name:"T-Shirt (Men)",category:"Fashion",price:18,rating:4.3,icon:"👕",description:"Soft everyday cotton T-shirt with a comfortable regular fit."},
{id:6,name:"Jeans (Men)",category:"Fashion",price:28,rating:4.5,icon:"👖",description:"Classic denim jeans designed for everyday comfort and durability."},
{id:7,name:"Handbag",category:"Bags",price:35,rating:4.7,icon:"👜",description:"Stylish everyday handbag with a practical interior."},
{id:8,name:"Wireless Headphones",category:"Electronics",price:40,rating:4.6,icon:"🎧",description:"Wireless headphones with comfortable ear cushions and clear sound."},
{id:9,name:"Kitchen Blender",category:"Home & Kitchen",price:55,rating:4.4,icon:"🥤",description:"Multi-speed kitchen blender for smoothies, sauces and more."},
{id:10,name:"Face Care Set",category:"Beauty & Health",price:32,rating:4.6,icon:"🧴",description:"Simple daily skincare set for a fresh, clean routine."},
{id:11,name:"Football",category:"Sports",price:25,rating:4.5,icon:"⚽",description:"Durable training football suitable for outdoor play."},
{id:12,name:"Bluetooth Speaker",category:"Electronics",price:48,rating:4.7,icon:"🔊",description:"Portable speaker with rich sound and wireless connectivity."}
];

let cart=JSON.parse(localStorage.getItem("remmaCart")||"[]");
let selectedCategory="All", searchTerm="";

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const money=n=>`$${n.toFixed(2)}`;

function save(){localStorage.setItem("remmaCart",JSON.stringify(cart));updateCartCount()}
function updateCartCount(){$("#cartCount").textContent=cart.reduce((s,i)=>s+i.qty,0)}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function stars(r){return "★".repeat(Math.round(r))+"☆".repeat(5-Math.round(r))}
function findProduct(id){return products.find(p=>p.id===Number(id))}

function productCard(p){
 return `<article class="product-card">
  <div class="product-image">${p.icon}</div>
  <div class="product-info">
   <h3>${p.name}</h3><div class="stars">${stars(p.rating)} <span class="muted">(${p.rating})</span></div>
   <div class="price">${money(p.price)}</div>
   <div class="product-actions"><button class="small-btn" onclick="showProduct(${p.id})">View</button><button class="small-btn add" onclick="addToCart(${p.id})">Add to Cart</button></div>
  </div>
 </article>`
}
function renderFeatured(){$("#featuredGrid").innerHTML=products.filter(p=>p.featured).map(productCard).join("")}
function filtered(){
 let list=products.filter(p=>(selectedCategory==="All"||p.category===selectedCategory)&&(!searchTerm||`${p.name} ${p.category}`.toLowerCase().includes(searchTerm.toLowerCase())));
 const sort=$("#sortSelect")?.value||"popular";
 if(sort==="low")list.sort((a,b)=>a.price-b.price);
 if(sort==="high")list.sort((a,b)=>b.price-a.price);
 if(sort==="rating")list.sort((a,b)=>b.rating-a.rating);
 return list
}
function renderShop(){const list=filtered();$("#resultsInfo").textContent=`Showing ${list.length} product${list.length===1?"":"s"}`;$("#productGrid").innerHTML=list.length?list.map(productCard).join(""):`<div class="empty">No products found. Try another search.</div>`}
function setCategory(cat){selectedCategory=cat;$$(".category-filter").forEach(b=>b.classList.toggle("active",b.dataset.category===cat));showView("shop");renderShop()}
function showView(name){
 $$(".view").forEach(v=>v.classList.remove("active"));
 const v=$("#"+name+"View");if(v)v.classList.add("active");
 window.scrollTo({top:0,behavior:"smooth"});
 if(name==="shop")renderShop(); if(name==="cart")renderCart(); if(name==="checkout")renderCheckout();
}
function showProduct(id){
 const p=findProduct(id);
 $("#productView").innerHTML=`<div class="product-detail">
 <div class="detail-image">${p.icon}</div><div class="detail-info">
 <p class="eyebrow">${p.category.toUpperCase()}</p><h1>${p.name}</h1><div class="stars">${stars(p.rating)} <span class="muted">(${p.rating})</span></div>
 <p class="price">${money(p.price)}</p><p class="muted">${p.description}</p>
 <div class="qty"><button onclick="changeDetailQty(-1)">−</button><span id="detailQty">1</span><button onclick="changeDetailQty(1)">+</button></div>
 <button class="primary" onclick="addDetailToCart(${p.id})">Add to Cart</button> <button class="secondary" onclick="addDetailToCart(${p.id});showView('cart')">Buy Now</button>
 <div class="features" style="margin-top:30px;grid-template-columns:repeat(3,1fr)"><div>🚚<b>Free Delivery</b></div><div>🛡️<b>Secure Payment</b></div><div>↩️<b>7 Days Return</b></div></div>
 </div></div>`;
 showView("product")
}
let detailQty=1;
function changeDetailQty(n){detailQty=Math.max(1,detailQty+n);$("#detailQty").textContent=detailQty}
function addDetailToCart(id){for(let i=0;i<detailQty;i++)addToCart(id,true);detailQty=1}
function addToCart(id,silent=false){const item=cart.find(i=>i.id===id);if(item)item.qty++;else cart.push({id,qty:1});save();if(!silent)toast("Added to cart")}
function changeQty(id,n){const item=cart.find(i=>i.id===id);if(!item)return;item.qty+=n;if(item.qty<=0)cart=cart.filter(i=>i.id!==id);save();renderCart()}
function removeItem(id){cart=cart.filter(i=>i.id!==id);save();renderCart()}
function totals(){const subtotal=cart.reduce((s,i)=>s+findProduct(i.id).price*i.qty,0);return{subtotal,shipping:subtotal?10:0,total:subtotal+(subtotal?10:0)}}
function renderCart(){
 if(!cart.length){$("#cartContent").innerHTML=`<div class="card empty"><h3>Your cart is empty</h3><p class="muted">Add some products to get started.</p><button class="primary" data-view="shop">Start Shopping</button></div>`;return}
 const t=totals();
 $("#cartContent").innerHTML=`<div class="card">${cart.map(i=>{const p=findProduct(i.id);return `<div class="cart-row"><div class="cart-thumb">${p.icon}</div><div><b>${p.name}</b><div class="muted">${p.category}</div></div><div class="cart-qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div><div class="price-col"><b>${money(p.price*i.qty)}</b></div><button onclick="removeItem(${p.id})" aria-label="Remove">🗑️</button></div>`}).join("")}<div class="summary-line"><span>Subtotal</span><b>${money(t.subtotal)}</b></div><div class="summary-line"><span>Shipping</span><b>${money(t.shipping)}</b></div><div class="summary-line summary-total"><span>Total</span><span>${money(t.total)}</span></div><div style="text-align:right;margin-top:15px"><button class="primary" onclick="showView('checkout')">Proceed to Checkout</button></div></div>`
}
function renderCheckout(){
 const t=totals();
 $("#checkoutSummary").innerHTML=`<h3>Order Summary</h3>${cart.map(i=>{const p=findProduct(i.id);return `<div class="summary-line"><span>${p.name} × ${i.qty}</span><b>${money(p.price*i.qty)}</b></div>`}).join("")}<div class="summary-line"><span>Subtotal</span><b>${money(t.subtotal)}</b></div><div class="summary-line"><span>Shipping</span><b>${money(t.shipping)}</b></div><div class="summary-line summary-total"><span>Total</span><span>${money(t.total)}</span></div>`
}
function openAuth(){ $("#authModal").classList.remove("hidden") }
function closeAuth(){ $("#authModal").classList.add("hidden") }

document.addEventListener("click",e=>{
 const viewBtn=e.target.closest("[data-view]");if(viewBtn){showView(viewBtn.dataset.view);return}
 const cat=e.target.closest("[data-category]");if(cat){setCategory(cat.dataset.category);$("#categoryMenu").classList.remove("open");return}
 if(e.target.matches("[data-close]"))closeAuth()
});
$("#categoryToggle").onclick=()=>$("#categoryMenu").classList.toggle("open");
$("#accountBtn").onclick=openAuth;
$("#cartBtn").onclick=()=>showView("cart");
$("#sortSelect").onchange=renderShop;
$("#searchInput").oninput=e=>{searchTerm=e.target.value;selectedCategory="All";$$(".category-filter").forEach(b=>b.classList.toggle("active",b.dataset.category==="All"));showView("shop")};
$("#searchBtn").onclick=()=>{searchTerm=$("#searchInput").value;showView("shop")};
$$(".category-filter").forEach(b=>b.onclick=()=>setCategory(b.dataset.category));
$("#registerSwitch").onclick=()=>{ $("#authTitle").textContent="Create Your Account"; $("#registerSwitch").textContent="Already have an account? Login"; toast("Registration mode enabled") };
$("#authForm").onsubmit=e=>{e.preventDefault();closeAuth();toast("You are now logged in");};
$("#checkoutForm").onsubmit=e=>{
 e.preventDefault();if(!cart.length){toast("Your cart is empty");showView("shop");return}
 const num="RMS"+Date.now().toString().slice(-8);$("#orderNumber").textContent=num;cart=[];save();showView("success");$("#checkoutForm").reset();
};
renderFeatured();renderShop();updateCartCount();
